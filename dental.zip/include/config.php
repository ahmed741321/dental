<?php
defined('server') ? null : define("server", "sql207.infinityfree.com");
defined('user') ? null : define("user", "if0_38091684");
defined('pass') ? null : define("pass", "Ah1no2ab3");
defined('database_name') ? null : define("database_name", "if0_38091684_dental");

// $web_root =  "https://mcguyverja.com/invoice/"; 
$web_root = $_SERVER['DOCUMENT_ROOT'] . "/";


define('web_root', $web_root);
